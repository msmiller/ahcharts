<?php

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//     FileName: M8Bcounter.php      //
//      Written by The M8B Team      //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

////////////////////////////////////////////////
//                                            //
//   Editing is not allowed past this point   //
//                                            //
////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//																		  	 //
// DON'T REMOVE ANY OF THE COPYRIGHT'S UNLESS YOU HAVE THE LICENSE TO DO SO! //
//																			 //
///////////////////////////////////////////////////////////////////////////////

// Check for direct access to this page.

if (eregi("M8Bcounter.php", $_SERVER[PHP_SELF])) {
    die ("Sorry but you are not allowed to access this file directly!");
}

include ('./M8Bcounter/config.php');
include ('./M8Bcounter/language.php');

// Check that the file paths are right.

if (!file_exists("$counterdata")) {
	die ("$lang_txt[5]!");
}

if (!file_exists("$userdata")) {
	die ("$lang_txt[6]!");
}

// Get the year from server.

$copyry = date("Y");

// Now to start outputing the data.

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>M8B Counter v<?php echo $version; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $lang_txt[7]; ?>">
<link rel="stylesheet" href="./M8Bcounter/m8bcounter.css">
</head>

<body>

<script type="text/javascript">
function openwindowupdate() {
window.open ("./M8Bcounter/update.php","update","width=600,height=200,scrollbars=no,resizable=no,toolbar=no,location=no,directories=no,status=no,menubar=no,copyhistory=no,");
}
</script>

<?php

if ($vertical == 1) {

include ('counterv.php');

} else {

include ('counterh.php');

}

?>

</body>
</html>
