<?php

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//     FileName: lang-english.php    //
//      Written by The M8B Team      //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////
//																				  //
// If you would like to translate this for us please feel free and send it to us. //
//																				  //
////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////
//                                            //
//   Editing is not allowed past this point   //
//                                            //
////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//																		  	 //
// DON'T REMOVE ANY OF THE COPYRIGHT'S UNLESS YOU HAVE THE LICENSE TO DO SO! //
//																			 //
///////////////////////////////////////////////////////////////////////////////

// Check for direct access to this page.

if (eregi("lang-english.php", $_SERVER[PHP_SELF])) {
    die ("Sorry but you are not allowed to access this file directly!");
}

// Language array.

$lang_txt[0] = 'Hit counter';
$lang_txt[1] = 'Visit counter';
$lang_txt[2] = 'Users online';
$lang_txt[3] = 'Page loadtime';
$lang_txt[4] = 'Sorry but you are not allowed to access this file directly';
$lang_txt[5] = 'ERROR ! counter data path is wrong, you need to setup the config file';
$lang_txt[6] = 'ERROR ! users data path is wrong, you need to setup the config file';
$lang_txt[7] = 'iso-8859-1';
$lang_txt[8] = 'Online Update Check';
$lang_txt[9] = 'Check new version Online';
$lang_txt[10] = 'It\'s ok, you have a last version ! But you can visit for fun';
$lang_txt[11] = 'A new version is available, you can download it here';
$lang_txt[12] = 'Your version is';
$lang_txt[13] = 'Last version availabe';
$lang_txt[14] = 'Close';
$lang_txt[15] = 'Version';
$lang_txt[16] = 'Update Check';
$lang_txt[17] = 'ERROR ! sorry but you have switched off the online update check, go to your config and switch it back on';
$lang_txt[18] = 'M8B Counter Online Update Check';

?>
