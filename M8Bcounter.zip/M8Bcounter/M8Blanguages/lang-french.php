<?php

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//     Mise � jour: 10-04-2006       //
// Nom du fichier: lang-french.php   //
//      Ecrit par le Team M8B        //
// 		Traduit par Francis Amar     //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//     License: Voir:license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

///////////////////////////////////////////////////////////////////////////
//											 							 //
// Il n'est pas n�cessaire de faire de modifications apr�s ce point      //
//                                           							 //
///////////////////////////////////////////////////////////////////////////

// V�rifiez l'acc�s direct � cette page.

if (eregi("lang-french.php", $_SERVER[PHP_SELF])) {
    die ("D�sol�, mais vous ne pouvez pas acc�der � ce fichier directement");
}

// Language array.

$lang_txt[0] = 'Compteur de "Hits"';
$lang_txt[1] = 'Compteur de visites';
$lang_txt[2] = 'Utilisateurs en ligne';
$lang_txt[3] = 'Temps de chargement de la page';
$lang_txt[4] = 'D�sol�, mais vous ne pouvez pas acc�der � ce fichier directement';
$lang_txt[5] = 'ERREUR ! Le chemin d\'acc�s aux donn�es du compteur est faux. Vous devez configurer le fichier "config"';
$lang_txt[6] = 'ERREUR ! Le chemin d\'acc�s aux donn�es des utilisateurs est faux.Vous devez configurer le fichier "config"';
$lang_txt[7] = 'iso-8859-1';
$lang_txt[8] = 'V�rifiez les mises � jour en ligne';
$lang_txt[9] = 'V�rifiez les nouvelles versions en ligne';
$lang_txt[10] = 'Tout va bien, vous avez la derni�re version ! Mais vous pouvez continuer votre visite pour le plaisir';
$lang_txt[11] = 'Une nouvelle version est disponible, vous pouvez la t�l�charger ici';
$lang_txt[12] = 'Votre version est';
$lang_txt[13] = 'Derni�re version disponible';
$lang_txt[14] = 'Fermez';
$lang_txt[15] = 'Version';
$lang_txt[16] = 'V�rification de mise � jour';
$lang_txt[17] = 'ERREUR ! D�sol�, mais vous avez d�branch� la v�rification des mises � jour en ligne. Allez dans votre configuration et rebranchez-la';
$lang_txt[18] = 'V�rification en ligne de mise � jour du compteur M8B';

?>
