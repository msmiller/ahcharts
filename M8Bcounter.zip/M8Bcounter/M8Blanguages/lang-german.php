<?php

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//     FileName: lang-german.php     //
//      Written by The M8B Team      //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////
//																				  //
// If you would like to translate this for us please feel free and send it to us. //
//																				  //
////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////
//                                            //
//   Editing is not allowed past this point   //
//                                            //
////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//																		  	 //
// DON'T REMOVE ANY OF THE COPYRIGHT'S UNLESS YOU HAVE THE LICENSE TO DO SO! //
//																			 //
///////////////////////////////////////////////////////////////////////////////

// Check for direct access to this page.

if (eregi("lang-english.php", $_SERVER[PHP_SELF])) {
    die ("Sorry but you are not allowed to access this file directly!");
}

// Language array.

$lang_txt[0] = 'Trefferz�hler';
$lang_txt[1] = 'Besuch Kostenz�hler';
$lang_txt[2] = 'Benutzer online';
$lang_txt[3] = 'Seite loadtime';
$lang_txt[4] = 'Traurig aber Sie werden nicht gew�hrt, um diese Akte direkt zug�nglich zu machen';
$lang_txt[5] = 'ST�RUNG! Gegendatenweg ist, Sie mu� die Configakte gr�nden falsch';
$lang_txt[6] = 'ST�RUNG! Benutzer, die Datenweg falsch sind, Sie, m�ssen die Configakte gr�nden';
$lang_txt[7] = 'iso-8859-1';
$lang_txt[8] = 'On-line-Update-�berpr�fung';
$lang_txt[9] = '�berpr�fen Sie die neue on-line Version';
$lang_txt[10] = 'Es ist, Sie hat eine letzte Version okay! Aber Sie k�nnen f�r Spa� besuchen';
$lang_txt[11] = 'Eine neue Version ist, Sie kann es hier downloaden vorhanden';
$lang_txt[12] = 'Ihre Version ist';
$lang_txt[13] = 'Letztes Version availabe';
$lang_txt[14] = 'Ende';
$lang_txt[15] = 'Version';
$lang_txt[16] = 'Update-�berpr�fung';
$lang_txt[17] = 'ST�RUNG! traurig aber Sie haben die on-line-Update�berpr�fung ausgeschaltet, zu Ihren Config gehen und schalten sie zur�ck an';
$lang_txt[18] = 'M8B Widersprechen On-line-Update-�berpr�fung';

?>
