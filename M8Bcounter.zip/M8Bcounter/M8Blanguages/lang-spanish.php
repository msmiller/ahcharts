<?php

///////////////////////////////////////////
//                                       //
//            M8BCounter                 //
//     Puesto a nivel: 10-04-2006        //
// Nombre del fichero: lang-spanish.php  //
//      Escribido por el Team M8B        //
// 		Traducido por Francis Amar       //
//       www.magic8ball.co.uk            //
//           Versi�n 1.2                 //
//     Licencia: Ver: license.txt        //
//              � 2006                   //
//                                       //
///////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
//                                            							//
//    No es necessario hacer modificaciones despues de este punto       //
//                                           						    //
//////////////////////////////////////////////////////////////////////////

// Verificar el accesso directo a esta p�gina.

if (eregi("lang-spanish.php", $_SERVER[PHP_SELF])) {
    die ("Desgraciadamente no pueden acceder a este fichero directamente !");
}

// Language array.

$lang_txt[0] = 'Contador de "Hits"';
$lang_txt[1] = 'Contador de visitas';
$lang_txt[2] = 'Usuarios en linea';
$lang_txt[3] = 'Tiempo de cargamento de la pagina';
$lang_txt[4] = 'Desgraciadamente no pueden acceder a este fichero directamente !';
$lang_txt[5] = 'ERROR ! El camino de acceso a los datos del contador esta erroneo. Debe configurar el fichero "config"';
$lang_txt[6] = 'ERROR ! El camino de acceso a los datos de los usuarios esta erroneo. Debe configurar el fichero "config"';
$lang_txt[7] = 'iso-8859-1';
$lang_txt[8] = 'Verificar puesta a nivel en linea';
$lang_txt[9] = 'Verificar nueva version en linea';
$lang_txt[10] = 'Esta bien, ya tiene la ultima version ! pero puede proder con la visita por placer';
$lang_txt[11] = 'Una nueva version esta disponible, la puede descargar aqui';
$lang_txt[12] = 'Su version es';
$lang_txt[13] = 'Ultima version disponible';
$lang_txt[14] = 'Cerrar';
$lang_txt[15] = 'Version';
$lang_txt[16] = 'Verificacion de puesta a nivel';
$lang_txt[17] = 'ERROR ! Desgraciadamente Usted ha desconectado la puesta a nivel en linea. Vaya a su configuracion para reconectarla';
$lang_txt[18] = 'Verificaci�n en linea de la puesta a nivel del contador M8B';

?>
