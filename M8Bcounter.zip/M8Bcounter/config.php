<?php

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//       FileName: config.php        //
//      Written by The M8B Team      //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

// Check for direct access to this page.

if (eregi("config.php", $_SERVER[PHP_SELF])) {
    die ("ERROR! sorry but you can't access this file directly.");
}

////////////////////////////////////
//                                //
// M8BCounter settings are below. //
//                                //
////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//																		  	 //
// DON'T REMOVE ANY OF THE COPYRIGHT'S UNLESS YOU HAVE THE LICENSE TO DO SO! //
//																			 //
///////////////////////////////////////////////////////////////////////////////

// To show the site counter: on = 1, off = 0, (Default is on).

$usercount = 1;


// To have the counter as a hit counter set to $hitcount = 1; and visit counter $hitcount = 0; (Default is on hit counter).
// Hit counter will count the number of page loads, visit counter will count the individual visits ie ip address.

$hitcount = 1;


// To show the number of users online: on = 1, off = 0, (Default is on),
// And set the minutes you want to store them for (Default is 10 mins).

$usersonline = 1;
$minutes = '10';


// You can change "style1" for any of the other style's in the style directory (Default is style1).

$style = 'style1';


// Counter type: Text = 0, Graphic = 1 (Default is Text).

$graphic = 0;


// Show the counter as Vertical = 1, or Horizontal = 0, (Default is Horizontal).
// And you can set the alignment :: left :: center :: right :: (Default is center)

$vertical = 0;
$alignment = 'center';


// To show the page load time of your site.

$loadtime = 1;


// You can set your language here (Default is english).
// :: english :: french :: spanish :: german ::

$language = 'english';


// Users data path (only change this if you need to).

$userdata = 'M8Bcounter/data/online.html';


// Counter data path (only change this if you need to).

$counterdata = 'M8Bcounter/data/counter.html';


// You only need to change this is you have changed the script name.

$filename = 'M8Bcounter.php';


// You only need to change this is you have changed the directory name.

$dirname = 'M8Bcounter';


// Update check: on = 1, off = 0, (Default is on).

$update = 1;

////////////////////////////////////////////////
//                                            //
//   Editing is not allowed past this point   //
//                                            //
////////////////////////////////////////////////

// Version number DO NOT CHANGE THIS!

$version = "1.2"; 

?>