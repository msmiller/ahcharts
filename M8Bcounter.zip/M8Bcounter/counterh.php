<?php

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//       FileName: counterh.php      //
//      Written by The M8B Team      //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

////////////////////////////////////////////////
//                                            //
//   Editing is not allowed past this point   //
//                                            //
////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//																		  	 //
// DON'T REMOVE ANY OF THE COPYRIGHT'S UNLESS YOU HAVE THE LICENSE TO DO SO! //
//																			 //
///////////////////////////////////////////////////////////////////////////////

if (eregi("counterh.php", $_SERVER[PHP_SELF])) {
    die ("Sorry but you can't access this file directly!");
}

?>

<table  align="<?php echo $alignment; ?>" border="0" cellspacing="0" cellpadding="0">
  <tr>
  <td>

<table align="center" border="0" cellspacing="0" cellpadding="6">
  <tr>

<?php

// M8BCounter hit script.

if ($usercount == 1) {

if ($hitcount == 1) {

	$file = fopen("$counterdata", "r");
	$count = fread($file, filesize("$counterdata"));
	fclose($file);

	$file = fopen("$counterdata", "w");
	$count = $count + 1;
	fwrite($file, $count);
	fclose($file);

if ($count < 10) {

	if ($graphic == 1) {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="textgraphic"><?php echo $lang_txt[0]; ?></font><br><?php echo '<img border="0" src="'.$dirname.'/styles/'.$style.'/0.gif" alt="0" title="0" /><img border="0" src="'.$dirname.'/styles/'.$style.'/'.$count.'.gif" alt="'.$count.'" title="'.$count.'" />'; ?>
  </td>

<?php

	} else {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="maintext"><?php echo $lang_txt[0]; ?>:&nbsp;</font><font class="counttext"><?php echo $count; ?></font></td>

<?php

	}

} else {

	if ($graphic == 1) {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="textgraphic"><?php echo $lang_txt[0]; ?></font><br>
<?php

		$char = "$count";
		$char_count = strlen($char);

		for ($i=0; $i<$char_count; $i++) {

			$number = $char{$i};
			echo '<img border="0" src="'.$dirname.'/styles/'.$style.'/'.$number.'.gif" alt="'.$number.'" title="'.$number.'" />';
		}
?>
  </td>
			
<?php

	} else {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="maintext"><?php echo $lang_txt[0]; ?>:&nbsp;</font><font class="counttext"><?php echo $count; ?></font></td>

<?php

	}

}
	} else {

// M8BCounter visit script.

$visitcount= file("$counterdata");

if( $_SERVER['REMOTE_ADDR'] !=$visitcount[1] ){
$count = $visitcount[0] + 1;
$ip =$_SERVER['REMOTE_ADDR'];


$fp= fopen("$counterdata", w);
fwrite($fp,$count. '
'. $ip);
fclose($fp);
}

if ($visitcount[0] < 10) {

	if ($graphic == 1) {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="textgraphic"><?php echo $lang_txt[1]; ?></font><br><?php echo '<img border="0" src="'.$dirname.'/styles/'.$style.'/0.gif" alt="0" title="0" /><img border="0" src="'.$dirname.'/styles/'.$style.'/'.$visitcount[0].'.gif" alt="'.$visitcount[0].'" title="'.$visitcount[0].'" />'; ?>
  </td>

<?php

	} else {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="maintext"><?php echo $lang_txt[1]; ?>:&nbsp;</font><font class="counttext"><?php echo $visitcount[0]; ?></font></td>

<?php

	}

} else {


	if ($graphic == 1) {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="textgraphic"><?php echo $lang_txt[1]; ?></font><br>
<?php

		$char = "$visitcount[0]";
		$char_coun = strlen($char);
		$char_count = $char_coun-1;

		for ($i=0; $i<$char_count; $i++) {

			$number = $char{$i};
			echo '<img border="0" src="'.$dirname.'/styles/'.$style.'/'.$number.'.gif" alt="'.$number.'" title="'.$number.'" />';

		}

?>
  </td>
			
<?php

	} else {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="maintext"><?php echo $lang_txt[1]; ?>:&nbsp;</font><font class="counttext"><?php echo $visitcount[0]; ?></font></td>

<?php

	}

}

}

}

// M8BCounter users online script.

if ($usersonline == 1) {

$ip = $_SERVER["REMOTE_ADDR"];
$time = time();
$found = 0;
$users = 0;
$user  = "";


$f = fopen("$userdata","r+");
flock($f,2);
while (!feof($f))
	{
	$user[] = chop(fgets($f,65536));
	}
fseek($f,0,SEEK_SET);
ftruncate($f,0);
foreach ($user as $line)
	{
	list($sip,$stime) = split("\|",$line);
	if ($sip == $ip) {$stime = $time;$found = 1;}
	if ($time < $stime + ($minutes * 60)) 
		{
		fputs($f,"$sip|$stime\n");
		$users = $users + 1;
		}
	}
if ($found == 0) 
	{
	fputs($f,"$ip|$time\n");
	$users = $users + 1;
	}
fclose ($f);

if ($users < 10) {

	if ($graphic == 1) {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="textgraphic"><?php echo $lang_txt[2]; ?></font><br><?php echo '<img border="0" src="'.$dirname.'/styles/'.$style.'/0.gif" alt="0" title="0" /><img border="0" src="'.$dirname.'/styles/'.$style.'/'.$users.'.gif" alt="'.$users.'" title="'.$users.'" />'; ?>
  </td>

<?php

	} else {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="maintext"><?php echo $lang_txt[2]; ?>:&nbsp;</font><font class="counttext"><?php echo $users; ?></font></td>

<?php

	}

} else {

	if ($graphic == 1) {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="textgraphic"><?php echo $lang_txt[2]; ?></font><br>
<?php

		$char = "$users";
		$char_count = strlen($char);

		for ($i=0; $i<$char_count; $i++) {

			$number = $char{$i};
			echo '<img border="0" src="'.$dirname.'/styles/'.$style.'/'.$number.'.gif" alt="'.$number.'" title="'.$number.'" />';

		}

?>
  </td>
			
<?php

	} else {

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="maintext"><?php echo $lang_txt[2]; ?>:&nbsp;</font><font class="counttext"><?php echo $users; ?></font></td>

<?php

	}

}

}

// Page load time script.

	if ($loadtime == 1) {

	if ($graphic == 1) {
?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="textgraphic"><?php echo $lang_txt[3]; ?>:</font><br>
<?php

		$execute = microtime();
		$char = "$execute";
		$char_coun = strlen($char);
		$char_count = $char_coun-15;

		for ($i=0; $i<$char_count; $i++) {

			$number = $char{$i};

			$string_replace = '_';
			$number = str_replace( ".", "$string_replace", $number );
			
			echo '<img border="0" src="'.$dirname.'/styles/'.$style.'/'.$number.'.gif" alt="'.$number.'" title="'.$number.'" />';

		}

?>
  </td>
			
<?php

	} else {

$execute = microtime();

?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

    <td align="center"><font class="maintext"><?php echo $lang_txt[3]; ?>:&nbsp;</font><font class="counttext"><?php print (number_format($execute,4)); ?>&nbsp;</font><font class="maintext">s</font></td>

<?php

	}

}

?>
  </tr>
</table>

<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

  <tr>
    <td align="center"><font class="copytext">M8BCounter v<?php echo $version; ?>&copy;&nbsp;<a class="copylinks" href='http://www.magic8ball.co.uk' target='_blank' title="PHP Magic 8 Ball">PHP Magic 8 Ball</a>&nbsp;<?php echo $copyry; ?></font></td>
  </tr>

<?php
if ($update == 1) {
?>
<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

  <tr>
    <td align="<?php echo $alignment; ?>"><font title="<?php echo $lang_txt[18]; ?>"><a class="updatecheck" href="javascript:openwindowupdate()"><?php echo $lang_txt[16]; ?></a></font></td>
  </tr>
<?php
}
?>

</table>
