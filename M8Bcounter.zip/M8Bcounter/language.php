<?php

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//      FileName: language.php       //
//      Written by The M8B Team      //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

////////////////////////////////////////////////
//                                            //
//   Editing is not allowed past this point   //
//                                            //
////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//																		  	 //
// DON'T REMOVE ANY OF THE COPYRIGHT'S UNLESS YOU HAVE THE LICENSE TO DO SO! //
//																			 //
///////////////////////////////////////////////////////////////////////////////

// Check for direct access to this page.

if (eregi("language.php", $_SERVER[PHP_SELF])) {
    die ("ERROR! sorry but you can't access this file directly.");
}

// Set the language that will be used.

if ($language == english) {
include ('M8Blanguages/lang-english.php');
}

if ($language == french) {
include ('M8Blanguages/lang-french.php');
}

if ($language == spanish) {
include ('M8Blanguages/lang-spanish.php');
}

if ($language == german) {
include ('M8Blanguages/lang-german.php');
}

?>