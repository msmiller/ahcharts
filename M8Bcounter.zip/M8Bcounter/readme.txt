
///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//       FileName: readme.txt        //
//      Written by The M8B Team      //
//       www.magic8ball.co.uk        //
//           Version 1.2             //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

1. Features.

* Easy instalation.
* You can display the counter in text or graphic format.
* Hit or visit counter.
* No database needed as it is a flat file system.
* 12 image styles to choose from (more coming soon).
* Online update check system.
* Counter can be set as Horizontal or Vertical.
* Language system with 4 dirrfent language's to choose from :: english :: french :: spanish :: german ::.
* Full CSS system for ease of adjusting the the look of it.
* Lots of settings for ease of customization.

////////////////////////////////////////////////////////////////////////////////////////////////////////

2. Clean instalation.

* Descompress the "M8Bcounter.zip" file.
* Upload the file "M8Bcounter" to your server.
* Use CHMOD to change the permissions for "counter.html" and "online.html" in the "data" file to 777.
* If you wish to see all the styles go " http://www.magic8ball.co.uk/modules.php?name=M8Bcounter ".
* Edit the settings in the file "M8Bcounter/config.php".
* Use this code below to display the counter results: 
* include ('./M8Bcounter/M8Bcounter.php');
	
////////////////////////////////////////////////////////////////////////////////////////////////////////

3. Upgrading from v1.0 to 1.2.

* Descompress the "M8Bcounter.zip" file.
* Delete the files "counter.html" and "online.html" in the "data" before you uploade it or you will loose your data!
* Upload the file "M8Bcounter" to your server.
* Reset up the settings in the file "M8Bcounter/config.php".

////////////////////////////////////////////////////////////////////////////////////////////////////////

* And that's all there is to it, if you have any problems with this counter just go :
* http://www.magic8ball.co.uk/modules.php?name=Forums&file=index&c=6
* Or use our live help if we are online!
* If you have some thing you would like to see in the counter just let us know!

////////////////////////////////////////////////////////////////////////////////////////////////////////
