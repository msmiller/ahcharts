<?

///////////////////////////////////////
//                                   //
//            M8BCounter             //
//        Updated: 10-04-2006        //
//       FileName: update.php        //
//    Written by magic8ball.co.uk    //
//       www.magic8ball.co.uk        //
//            Version 1.2            //
//      License: See license.txt     //
//              � 2006               //
//                                   //
///////////////////////////////////////

////////////////////////////////////////////////
//                                            //
//   Editing is not allowed past this point   //
//                                            //
////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
//																		  	 //
// DON'T REMOVE ANY OF THE COPYRIGHT'S UNLESS YOU HAVE THE LICENSE TO DO SO! //
//																			 //
///////////////////////////////////////////////////////////////////////////////

include ('./config.php');
include ('./language.php');

// Check to see if online update check is on.

if ($update == 0) {
if (eregi("update.php", $_SERVER[PHP_SELF])) {
    die ("$lang_txt[17].");
}
}

// Check for close window.

if (!empty($_GET["a"])) {
?>
<script type="text/javascript">window.close()</script>
<?php
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title><?php echo ':: '.$lang_txt[8].'  :: ~ M8Bcounter v'.$version.' ~ '; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $lang_txt[7]; ?>">
<link rel="stylesheet" href="./m8bcounter.css">
</head>

<body>

<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

<?php

// Update checking function.

Class Process
{
	function Process()
	{

		include ('config.php');
		$this->Version = "$version";
		$this->checkupdate = true;
	}

	function CheckVersion($check = true)
	{
		$errno = '';
		$errstr = '';
		$fp = fsockopen ("www.magic8ball.co.uk", 80, $errno, $errstr, 5);
		
		if ($fp)
		{
			fputs ($fp, "GET /update/counterupdate.php HTTP/1.0\r\nHost: www.magic8ball.co.uk\r\n\r\n");
			while (!feof($fp))
			   $contents = fgets ($fp,128);
			fclose ($fp);

			return $contents;			
		}
	}
}

Class Stats_Display extends process
{
	function Stats_Display()
	{
		$this->Process();
	}

 	function Version()
	{

		// Get the year from server.

		$copyry = date("Y");

		include ('./config.php');
		include ('./language.php');

		$check = $this->CheckVersion();
		$prv = explode("=", $check);
		$prv = explode("|", $prv[1]);
		
		$version = $prv[0];
		$url = $prv[1];
	
		if ($check == false)
			$Message = "<p><font class='topupdatetext'>$lang_txt[9]<a class='updatelinks' href='http://www.magic8ball.co.uk' target='_blank' title='PHP Magic 8 Ball'>www.magic8ball.co.uk</a></font></p>";
		else
		{
			if($version == $this->Version)
				$Message = "<p><font class='maintext'>$lang_txt[10] <a class='updatelinks' href='http://www.magic8ball.co.uk' target='_blank' title='PHP Magic 8 Ball'>www.magic8ball.co.uk</a></font></p>";
			else
				$Message = "<p><font class='maintext'>$lang_txt[11] <a class='updatelinks' href='$url' target='_blank' title='PHP Magic 8 Ball'>www.magic8ball.co.uk</a></font></p>";				
		}
		?>
		<table border='0' align='center' cellspacing='0' cellpadding='0' width='100%'>
			<tr class='bg2'>
				<td colspan='4'><p><font class='topupdatetext'>&nbsp;&nbsp;<?php echo $lang_txt[9]; ?></font></p></td>
			</tr>
			<tr class='bg'>
				<td width='15%'>&nbsp;</td>
				<td class='bg' colspan='4'>&nbsp;</td>
			</tr>
			<tr class='bg'>
				<td width='15%'>&nbsp;</td>
				<td class='bg' colspan='4'><p><font class='maintext'><?php echo $lang_txt[12]; ?>&nbsp;:&nbsp;<?php echo $lang_txt[15]; ?>&nbsp;<?= $this->Version ?></font></p></td>
			</tr>
			<tr class='bg'>
				<td width='15%'>&nbsp;</td>
				<td class='bg' colspan='4'><p><font class='maintext'><?php echo $lang_txt[13]; ?>&nbsp;:&nbsp;<?php echo $lang_txt[15]; ?>&nbsp;<?= $version ?></font></p></td>
			</tr>
			<tr class='bg'>
				<td width='15%'>&nbsp;</td>
				<td class='bg' colspan='4'>&nbsp;</td>
			</tr>
			<tr class='bg'>
				<td width='15%'>&nbsp;</td>
				<td class='bg' colspan='4'><?= $Message ?></td>
			</tr>
			<tr class='bg'>
				<td width='15%'>&nbsp;</td>
				<td class='bg' colspan='4'>&nbsp;</td>
			</tr>

			<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
			<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

			<tr class='bg2' >
				<td align='left' colspan='2' width='80%'><font class='copytext'>&nbsp;&nbsp;M8BCounter v<?php echo $version; ?>&copy;&nbsp;<a class='copylinks' href='http://www.magic8ball.co.uk' target='_blank' title='PHP Magic 8 Ball'>PHP Magic 8 Ball</a>&nbsp;<?php echo $copyry; ?></font></td>
				<td align='right' colspan='2'><p><a class='updatelinks' href='<?=$PHP_SELF?>?a=close' title="<?php echo $lang_txt[14]; ?>"><?php echo $lang_txt[14]; ?></a>&nbsp;&nbsp;</p></td>
			</tr>
		</table>
		<?

	}
}

// Now to display the data.

$dsp = new Stats_Display();

$dsp->Version();

?>

<!--         DO NOT REMOVE THE COPYRIGHT NOTICE OF "magic8ball.co.uk"        -->
<!-- copyright PHP Magic 8 Ball, http://www.magic8ball.co.uk [DO NOT DELETE] -->

</body>
</html>